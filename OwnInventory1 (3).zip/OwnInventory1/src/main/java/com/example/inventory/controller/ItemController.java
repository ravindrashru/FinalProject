package com.example.inventory.controller;

import java.util.List;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.example.inventory.entity.Item;
import com.example.inventory.service.ItemService;
@RestController
@RequestMapping("/api/inventoryitem/item")
public class ItemController {
	private ItemService itemService;

	public ItemController(ItemService itemService) {
		super();
		this.itemService = itemService;
	}
	
	public ItemController() {}
	
	
	@PostMapping
	public ResponseEntity<Item>saveItem(@RequestBody Item item) {
		return new ResponseEntity<Item>(HttpStatus.CREATED);
	}
	

	@GetMapping
	public List<Item> getAllItem()
	{
		return itemService.getAllItem();
	}
	@GetMapping("{id}")
	public ResponseEntity<Item>getProductById(@PathVariable("id") long id) {
		return new ResponseEntity<Item>(itemService.getItemById(id), HttpStatus.OK);
	}
	
	@PutMapping("{id}")
	public ResponseEntity<Item> updateItem(@PathVariable("id") long id, @RequestBody Item item){
		
		return new ResponseEntity<Item>(itemService.updateItem(item, id),HttpStatus.OK);
		
	}
	
}
