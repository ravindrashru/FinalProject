package com.example.inventory.controller;


import java.util.List;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.example.inventory.entity.Purchase;
import com.example.inventory.service.PurchaseService;
@RestController
@RequestMapping("/api/inventoryitem/purchase")
public class PurchaseController {
	private PurchaseService PurchaseService;

	public PurchaseController(PurchaseService PurchaseService) {
		super();
		this.PurchaseService = PurchaseService;
	}
	
	public PurchaseController() {}
	
	@PostMapping
	public ResponseEntity<Purchase>savePurchase(@RequestBody Purchase purchase) {
		return new ResponseEntity<Purchase>(HttpStatus.CREATED);
	}
	

	@GetMapping
	public List<Purchase> getAllpurchase()
	{
		return ((PurchaseController) PurchaseService).getAllpurchase();
	}
	@GetMapping("{id}")
	public ResponseEntity<Purchase> getProductById(@PathVariable("id") long id) {
		return new ResponseEntity<Purchase>(HttpStatus.OK);
	}
	
	@PutMapping("{id}")
	public ResponseEntity<Purchase> UpdatePurchase(@RequestBody Purchase purchase, @PathVariable("id") long id){
		
		return new ResponseEntity<Purchase>(HttpStatus.OK);
		
	}
	
}

