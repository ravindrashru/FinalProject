package com.example.inventory.entity;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.JoinTable;
import javax.persistence.ManyToOne;
//import javax.persistence.JoinTable;
//import javax.persistence.JoinColumn;
//import javax.persistence.ManyToOne;
import javax.persistence.Table;

//import com.fasterxml.jackson.annotation.JsonBackReference;

//import com.fasterxml.jackson.annotation.JsonBackReference;


@Entity
@Table(name="InventoryPurchaseTbl")
public class Purchase {
	@Id
	@GeneratedValue(strategy= GenerationType.IDENTITY)private long id;
	@Column(name="item_name")
	private String itemName;
	@Column(name="item_number")
	private int itemNumber;
	@Column(name="quantity")
	private long quantity;
	@Column(name="vendor_name")
	private String vendorName;
	@Column(name="purchase_id")
	private int purchaseId;
	@Column(name="unity_price")
	private long unityPrice;
	@Column(name="current_stock")
	private long currentStock;
	@Column(name="sale_date")
	private long saleDate;
	@Column(name="total_cost")
	private long totalCost;
	
	
	
@ManyToOne
	
    @JoinTable(name="item_sale",joinColumns = { @JoinColumn(name="item_id")},inverseJoinColumns = { @JoinColumn(name="sale_id")})

    
	
	public long getId() {
		return id;
	}
	public void setId(long id) {
		this.id = id;
	}
	public String getItemName() {
		return itemName;
	}
	public void setItemName(String itemName) {
		this.itemName = itemName;
	}
	public int getItemNumber() {
		return itemNumber;
	}
	public void setItemNumber(int itemNumber) {
		this.itemNumber = itemNumber;
	}
	public long getQuantity() {
		return quantity;
	}
	public void setQuantity(long quantity) {
		this.quantity = quantity;
	}
	public String getVendorName() {
		return vendorName;
	}
	public void setVendorName(String vendorName) {
		this.vendorName = vendorName;
	}
	public int getPurchaseId() {
		return purchaseId;
	}
	public void setPurchaseId(int purchaseId) {
		this.purchaseId = purchaseId;
	}
	public long getUnityPrice() {
		return unityPrice;
	}
	public void setUnityPrice(long unityPrice) {
		this.unityPrice = unityPrice;
	}
	public long getCurrentStock() {
		return currentStock;
	}
	public void setCurrentStock(long currentStock) {
		this.currentStock = currentStock;
	}
	public long getSaleDate() {
		return saleDate;
	}
	public void setSaleDate(long saleDate) {
		this.saleDate = saleDate;
	}
	public long getTotalCost() {
		return totalCost;
	}
	public void setTotalCost(long totalCost) {
		this.totalCost = totalCost;
	}

		public Purchase(long id, String itemName, int itemNumber,long quantity, String vendorName, 
				int purchaseId, long unityPrice, long currentStock, long saleDate, long totalCost) {
			super();
			this.id = id;
			this.itemName = itemName;
			this.quantity = quantity;
			this.vendorName = vendorName;
			this.purchaseId = purchaseId;
			this.unityPrice = unityPrice;
			this.currentStock = currentStock;
	        this.saleDate =  saleDate;
	        this.totalCost = totalCost;
	        }
		
		
		@Override
		public String toString() {
		return "Purchase [id=" + id + ", itemName=" + itemName + ", quantity=" + quantity + ", vendorName=" + vendorName + ", purchaseId=" + purchaseId 
					+ ",unityPrice=" + unityPrice + ", currentStock="+ currentStock + ",  saleDate=" + saleDate + ", totalCost=" + totalCost + "]";


		}
		public Purchase() {
			super();
			// TODO Auto-generated constructor stub
		}


		}

			
	
	
