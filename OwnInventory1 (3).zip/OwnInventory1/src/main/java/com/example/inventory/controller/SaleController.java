package com.example.inventory.controller;


import java.util.List;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.example.inventory.entity.Sale;
import com.example.inventory.service.SaleService;
@RestController
@RequestMapping("/api/inventoryitem/sale")
public class SaleController {
	private Object saleService;

	public SaleController(SaleService SaleService) {
		super();
		
	}
	
	public SaleController() {}
	
	@PostMapping
	public ResponseEntity<Sale>saveSale(@RequestBody Sale sale) {
		return new ResponseEntity<Sale>(HttpStatus.CREATED);
	}
	

	@GetMapping
	public List<Sale> getAllSale()
	{
		return ((SaleController) saleService).getAllSale();
	}
	@GetMapping("{id}")
	public ResponseEntity<Sale> getProductById(@PathVariable("id") long id) {
		return new ResponseEntity<Sale>(HttpStatus.OK);
	}
	
	@PutMapping("{id}")
	public ResponseEntity<Sale> updateSale(@RequestBody Sale sale, @PathVariable("id") long id){
		
		return new ResponseEntity<Sale>(HttpStatus.OK);
		
	}
	
}

