package com.example.inventory.service;


import java.util.List;

import org.springframework.stereotype.Service;

import com.example.inventory.entity.Item;
@Service
public interface PurchaseService {
	Item getItemById(long id);

	String validateItemId(long id);

	long findItemIdByLoanId(long loanId);

	List<Item> getAllItems();

	void saveItem(Item item);

	String validateItemId(String itemName, String itemNumber);

	void deleteItem(long itemId);

	Item updateItem(Item item, long id);

	List<Item> getAllItem();
	
}
	
