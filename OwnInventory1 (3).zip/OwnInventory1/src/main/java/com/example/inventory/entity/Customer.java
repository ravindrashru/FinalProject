package com.example.inventory.entity;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.JoinTable;
import javax.persistence.ManyToOne;
//import javax.persistence.JoinTable;
//import javax.persistence.JoinColumn;
//import javax.persistence.ManyToOne;
import javax.persistence.Table;


//import com.fasterxml.jackson.annotation.JsonBackReference;

@Entity
@Table(name = "InventoryCustomerTbl")
public class Customer {
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private long id;
	@Column(name = "full_name")
	private String fullName;
	@Column(name = "phone_number")
	private int phoneNumber;
	@Column(name = "phone2")
	private int phone2;
	@Column(name = "email")
	private String email;
	@Column(name = "customer_id")
	private int customerId;
	@Column(name = "address")
	private String address;
	@Column(name = "address2")
	private String address2;
	@Column(name = "status")
	private String status;
	@Column(name = "city")
	private String city;
	@Column(name = "district")
	private String district;

	@ManyToOne

	@JoinTable(name = "product_customer", joinColumns = { @JoinColumn(name = "product_id") }, inverseJoinColumns = {
			@JoinColumn(name = "customer_id") })

	public long getId() {
		return id;
	}

	public void setId(long id) {
		this.id = id;
	}

	public String getFullName() {
		return fullName;
	}

	public void setFullName(String fullName) {
		this.fullName = fullName;
	}

	public int getPhoneNumber() {
		return phoneNumber;
	}

	public void setPhoneNumber(int phoneNumber) {
		this.phoneNumber = phoneNumber;
	}

	public int getPhone2() {
		return phone2;
	}

	public void setPhone2(int phone2) {
		this.phone2 = phone2;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public int getCustomerId() {
		return customerId;
	}

	public void setCustomerId(int customerId) {
		this.customerId = customerId;
	}

	public String getAddress() {
		return address;
	}

	public void setAddress(String address) {
		this.address = address;
	}

	public String getAddress2() {
		return address2;
	}

	public void setAddress2(String address2) {
		this.address2 = address2;
	}

	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}

	public String getCity() {
		return city;
	}

	public void setCity(String city) {
		this.city = city;
	}

	public String getDistrict() {
		return district;
	}

	public void setDistrict(String district) {
		this.district = district;
	}

	public Customer(long id, String fullName, int phoneNumber, int phone2, String email, int customerId, String address,
			String address2, String status, String city, String district) {
		super();
		this.id = id;
		this.fullName = fullName;
		this.phoneNumber = phoneNumber;
		this.phone2 = phone2;
		this.email = email;
		this.customerId = customerId;
		this.address = address;
		this.address2 = address2;
		this.status = status;
		this.city = city;
		this.district = district;
	}

	@Override
	public String toString() {
		return "Customer [id=" + id + ", fullName=" + fullName + ", phoneNumber=" + phoneNumber + ", phone2=" + phone2
				+ ", email=" + email + ",customerId=" + customerId + ", address=" + address
				+ ", address2= "+ address2 + ", status= "+ status + ", city="+ city + ",district= "+ district + "]";

	}

	public Customer() {
		super();
		// TODO Auto-generated constructor stub
	}

}
