package com.example.inventory.controller;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.example.inventory.entity.Customer;
import com.example.inventory.repository.CustomerRepository;
import com.example.inventory.service.CustomerService;
@RestController
@RequestMapping("/api/inventoryitem/customer")

public class CustomerController {
	
	private CustomerService CustomerService;
	private CustomerRepository CustomerRepository;

	public CustomerController(CustomerService CustomerService) {
		super();
		this.CustomerService = CustomerService;
	}
	
	public CustomerController() {}
	
	@PostMapping
	public ResponseEntity<Customer>saveCustomer(@RequestBody Customer customer) {
		return new ResponseEntity<Customer>(HttpStatus.CREATED);
	}
	

	@GetMapping("/getCustomer")
	public ResponseEntity<Customer> getAllcustomer()
	{
		return ((CustomerController) CustomerService).getAllcustomer();
	}
	@GetMapping("{id}")
	public ResponseEntity<Customer> getProductById(@PathVariable("id") long id) {
		return new ResponseEntity<Customer>(HttpStatus.OK);
	}
	
	@PutMapping("{id}")
	public ResponseEntity<Customer> UpdateCustomer(@RequestBody Customer customer, @PathVariable("id") long id){
		
		return new ResponseEntity<Customer>(HttpStatus.OK);
		
	}
	
}


