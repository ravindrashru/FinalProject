package com.example.inventory.service;

import java.util.List;
import java.util.Optional;

import org.springframework.stereotype.Service;

import com.example.inventory.entity.Users;
@Service
public interface UsersService {
   public Optional<Users> findUserByUserName(String userName);

Users saveUser(Users users);

List<Users> getAllUsers();

Users getUserById(long id);

Users updateUsers(Users users, long id);

public Users saveUsers(Users users);


//public void deleteUser(long id);


   
}