package com.example.inventory.service;


import java.util.List;

import org.springframework.stereotype.Service;

import com.example.inventory.entity.Customer;
@Service
public interface CustomerService {
	
	Customer saveCustomer(Customer customer);
	List<Customer> getAllCustomer();
	Customer getCustomerById(long id);
	Customer updateCustomer(Customer customer, long id);
	void deleteCustomer(long id);
	List<Customer> getCustomerByName(String name);
}
