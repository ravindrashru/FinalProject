package com.example.inventory.entity;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.JoinTable;
import javax.persistence.ManyToOne;
//import javax.persistence.JoinTable;
//import javax.persistence.JoinColumn;
//import javax.persistence.ManyToOne;
import javax.persistence.Table;

//import com.fasterxml.jackson.annotation.JsonBackReference;

//import com.fasterxml.jackson.annotation.JsonBackReference;


@Entity
@Table(name="InventoryItemTbl")
public class Item {
	@Id
	@GeneratedValue(strategy= GenerationType.IDENTITY)private long id;
	@Column(name="item_name")
	private String itemName;
	@Column(name="item_number")
	private int itemNumber;
	@Column(name="quantity")
	private long quantity;
	@Column(name="description")
	private String description;
	@Column(name="product_id")
	private int productId;
	@Column(name="unit_price")
	private long unitPrice;
	@Column(name="total_price")
	private long totalPrice;
@ManyToOne
	
    @JoinTable(name="product_customer",joinColumns = { @JoinColumn(name="product_id")},inverseJoinColumns = { @JoinColumn(name="customer_id")})
    
   
public long getId() {
	return id;
}
public void setId(long id) {
	this.id = id;
}
public String getItemName() {
	return itemName;
}
public void setItemName(String itemName) {
	this.itemName = itemName;
}
public int getItemNumber() {
	return itemNumber;
}
public void setItemNumber(int itemNumber) {
	this.itemNumber = itemNumber;
}
public long getQuantity() {
	return quantity;
}
public void setQuantity(long quantity) {
	this.quantity = quantity;
}
public String getProductDesc() {
	return description;
}
public void setProductDesc(String productDesc) {
	this.description = productDesc;
}
public int getProductId() {
	return productId;
}
public void setProductId(int productId) {
	this.productId = productId;
}
public long getUnitPrice() {
	return unitPrice;
}
public void setUnitPrice(long unitPrice) {
	this.unitPrice = unitPrice;
}
public long getTotalPrice() {
	return totalPrice;
}
public void setTotalPrice(long totalPrice) {
	this.totalPrice = totalPrice;
}

public Item(long id, String itemName, int itemNumber,long quantity, String description,
		int productId, long unitPrice, long totalPrice) {
	super();
	this.id = id;
	this.itemName = itemName;
	this.quantity = quantity;
	this.description = description;
	this.productId = productId;
	this.unitPrice = unitPrice;
	this.totalPrice = totalPrice;
}

@Override
public String toString() {
	return "Product [id=" + id + ", itemName=" + itemName + ", quantity=" + quantity + ", description=" + description + ", productId=" + productId 
			+ ",unitPrice=" + unitPrice + ", totalPrice="+ totalPrice + "]";
			
}

public Item() {
	super();
	// TODO Auto-generated constructor stub
}


}



	
