package com.example.inventory;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.data.jpa.repository.config.EnableJpaRepositories;
import com.example.inventory.repository.CustomerRepository;

@SpringBootApplication(scanBasePackages={"com.example.inventory.service"})
@EnableJpaRepositories(basePackageClasses = CustomerRepository.class)
@ComponentScan(basePackages = "com.example.inventory.controller")
public class OwnInventory1Application {

	public static void main(String[] args) {
		SpringApplication.run(OwnInventory1Application.class, args);
	}

}
